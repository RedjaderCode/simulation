//main.cpp

// I want to use this matrix to simulate a 3dimensional environment

/*
size_t index = z * height * width + y * width + x;

// Reverse:
x = index % width;
y = (index / width) % height;
z = index / (width * height);
*/

#include <windows.h>
#include <windowsx.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cmath>
#include <memory>

#ifndef UNICODE
#define UNICODE
#error flag -DUNICODE
#endif

#define GetInstance() GetModuleHandle(NULL)
#define CHECK_MATRIX_POPULATION() do{if(!matrix){return DefWindowProc(hwnd, msg, wp, lp);}}while(0)
#define CHECK_MATRIX_WALLS() x == 0 || x == w -1 || y == 0 || y == h -1 || z == 0 || z == d -1

struct COORD3D{ uint32_t x; uint32_t y; uint32_t z; COORD3D(uint32_t _x, uint32_t _y, uint32_t _z) : x(_x), y(_y), z(_z) {} };
struct Vec3D  { float x; float y; float z; Vec3D(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {} };

struct MATRIX
{
public:
	enum element{air, water, wood, fire, metal, Custom, size};

	struct MaterialAttributes
	{
		float density;
		float friction;
		float thermalConductivity; // rate of heat transfer
		float specificHeat; // energy to raise 1 kg by 1 degree Celcius
		float restitution; // bounciness
		float hardness;
		bool  liguid;

		const char* name = nullptr;
	};
	struct cell
	{
		cell() = default;
		cell(element _MaterialType) : MaterialType(_MaterialType) {}
		cell(float _tempurature)    : temperature(_tempurature)   {}
		cell(Vec3D _velocity)       : velocity(_velocity)         {}
		cell(double _pressure)      : pressure(_pressure)         {}

		float temperature = 0.0f;
		Vec3D velocity    = Vec3D(0.0f, 0.0f, 0.0f);
		double pressure   = 0.0;
		bool active = false;

		element MaterialType;
	};
public:
	uint32_t InitMatrix(uint32_t width, uint32_t height, uint32_t depth)
	{
		//void* mamory = malloc(sizeof(cell) * (width * height* depth));
		//cell* CELL_FRONT_BUFFER = new(memory) cell[width * height* depth];

		CELL_FRONT_BUFFER = std::unique_ptr<cell[]>(new cell[width * height * depth]);
		CELL_BACK_BUFFER  = std::unique_ptr<cell[]>(new cell[width * height * depth]);
		matAtt     		  = std::unique_ptr<MaterialAttributes[]>(new MaterialAttributes[static_cast<uint32_t>(element::size)]);
		w = width; h = height; d = depth;

		printf("-> cells set to: element::air\n");
		for(uint32_t i=0; i<= width * height * depth -1; ++i)
		{
			//CELL_BACK_BUFFER[i].MaterialType = element::air;
			uint32_t x = i % w; uint32_t y = (i / w) % h; uint32_t z = i / (w * h);
			cell back_buffer_cell = CHECK_MATRIX_WALLS() ? WriteDataTo(x, y, z, cell(element::Custom)) : WriteDataTo(x, y, z, cell(element::air));
		}

		// create an initializer field for attributes of materials to tell the cells what their attributes are
		printf("-> elements::name... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].name 			   = "air";
		matAtt[static_cast<uint32_t>(element::water) ].name 			   = "water";
		matAtt[static_cast<uint32_t>(element::wood)  ].name 			   = "wood";
		matAtt[static_cast<uint32_t>(element::fire)  ].name 			   = "fire";
		matAtt[static_cast<uint32_t>(element::metal) ].name 			   = "metal";
		matAtt[static_cast<uint32_t>(element::Custom)].name 			   = "Custom";

		printf("-> elements::density... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].density 			   = 1.225f;
		matAtt[static_cast<uint32_t>(element::water) ].density 			   = 1000.0f;
		matAtt[static_cast<uint32_t>(element::wood)  ].density 			   = 700.0f;
		matAtt[static_cast<uint32_t>(element::fire)  ].density 			   = 0.0f;
		matAtt[static_cast<uint32_t>(element::metal) ].density 			   = 7800.0f;
		matAtt[static_cast<uint32_t>(element::Custom)].density 			   = 0.0f;
		
		printf("-> elements::friction... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].friction 		   = 0.02f;
		matAtt[static_cast<uint32_t>(element::water) ].friction 		   = 0.1f;
		matAtt[static_cast<uint32_t>(element::wood)  ].friction 		   = 0.4f;
		matAtt[static_cast<uint32_t>(element::fire)  ].friction 		   = 0.0f;
		matAtt[static_cast<uint32_t>(element::metal) ].friction 		   = 0.6f;
		matAtt[static_cast<uint32_t>(element::Custom)].friction 		   = 0.0f;

		printf("-> elements::ThermalConductivity... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].thermalConductivity = 0.025f;
		matAtt[static_cast<uint32_t>(element::water) ].thermalConductivity = 0.6f;
		matAtt[static_cast<uint32_t>(element::wood)  ].thermalConductivity = 0.12f;
		matAtt[static_cast<uint32_t>(element::fire)  ].thermalConductivity = 0.0f;
		matAtt[static_cast<uint32_t>(element::metal) ].thermalConductivity = 400.0f;
		matAtt[static_cast<uint32_t>(element::Custom)].thermalConductivity = 0.0f;

		printf("-> elements::specificHeat... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].specificHeat 	   = 1005.0f;
		matAtt[static_cast<uint32_t>(element::water) ].specificHeat 	   = 4186.0f;
		matAtt[static_cast<uint32_t>(element::wood)  ].specificHeat 	   = 2400.0f;
		matAtt[static_cast<uint32_t>(element::fire)  ].specificHeat 	   = 0.0f;
		matAtt[static_cast<uint32_t>(element::metal) ].specificHeat 	   = 450.0f;
		matAtt[static_cast<uint32_t>(element::Custom)].specificHeat 	   = 0.0f;

		printf("-> elements::restitution... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].restitution 		   = 0.0f;
		matAtt[static_cast<uint32_t>(element::water) ].restitution 		   = 0.1f;
		matAtt[static_cast<uint32_t>(element::wood)  ].restitution 		   = 0.3f;
		matAtt[static_cast<uint32_t>(element::fire)  ].restitution 		   = 0.0f;
		matAtt[static_cast<uint32_t>(element::metal) ].restitution 		   = 0.9f;
		matAtt[static_cast<uint32_t>(element::Custom)].restitution 		   = 0.0f;

		printf("-> elements::hardness... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].hardness 		   = 0.0f;
		matAtt[static_cast<uint32_t>(element::water) ].hardness 		   = 0.1f;
		matAtt[static_cast<uint32_t>(element::wood)  ].hardness 		   = 0.3f;
		matAtt[static_cast<uint32_t>(element::fire)  ].hardness 		   = 0.0f;
		matAtt[static_cast<uint32_t>(element::metal) ].hardness 		   = 0.9f;
		matAtt[static_cast<uint32_t>(element::Custom)].hardness 		   = 10000.0f;
			   
		printf("-> elements::hardness... \n");
		matAtt[static_cast<uint32_t>(element::air)   ].liguid 			   = false;
		matAtt[static_cast<uint32_t>(element::water) ].liguid 			   = true;
		matAtt[static_cast<uint32_t>(element::wood)  ].liguid 			   = false;
		matAtt[static_cast<uint32_t>(element::fire)  ].liguid 			   = false;
		matAtt[static_cast<uint32_t>(element::metal) ].liguid 			   = false;
		matAtt[static_cast<uint32_t>(element::Custom)].liguid 			   = false;

		

		printf("matrix initialized: CELLS: [%d] BPC: [%d]\n\n", (w*h*d), sizeof(CELL_BACK_BUFFER[0]));
		return width * height * depth;
	}

	cell AccessDataAt(uint32_t x, uint32_t y, uint32_t z)
	{ 
		x = x>w ? w : x; y = y>h ? h : y; z = z>d ? d : z;
		return CELL_BACK_BUFFER[FlattenedIndex(x, y, z)]; // [x][y][z]
	}

	cell WriteDataTo(uint32_t x, uint32_t y, uint32_t z, const cell& _data)
	{
		x = x>w ? w : x; y = y>h ? h : y; z = z>d ? d : z;
		CELL_BACK_BUFFER[FlattenedIndex(x, y, z)] = _data; // [x][y][z]
		return CELL_BACK_BUFFER[FlattenedIndex(x, y, z)];
	}

	inline void update(HWND hwnd)
	{
		for(uint32_t i=0; i<=w*h*d - 1; ++i)
		{
			uint32_t x = i % w; uint32_t y = (i / w) % h; uint32_t z = i / (w * h);
			cell readCell = CHECK_MATRIX_WALLS() ? WriteDataTo(x, y, z, cell(element::Custom)) : cell();
			MaterialAttributes MA = ReadCellAttributes(readCell); // read that these cells can't be destroyed... pretty much
		}
		for(uint32_t i=0; i<=w*h*d -1; ++i)
		{
			if(CELL_BACK_BUFFER[i].MaterialType != CELL_FRONT_BUFFER[i].MaterialType)
			{
				// copy the back buffer to the front buffer up until the point at which a cell tranformation was detected
				memcpy(CELL_FRONT_BUFFER.get(), CELL_BACK_BUFFER.get(), sizeof(cell) * w*h*d - sizeof(cell) * i);
				InvalidateRect(hwnd, nullptr, FALSE);
				break;
			}
		}
	}

	//uint32_t GetWidth (){ return this->w; }
	//uint32_t GetHeight(){ return this->h; }
	//uint32_t GetDepth (){ return this->d; }

	//uint16_t GetPixelWidth() { return this->_pixelWidth;  }
	//uint16_t GetPixelHeight(){ return this->_pixelHeight; }

	//void     SetPixelWidth (uint16_t _pw){ this->_pixelWidth  = _pw; }
	//void     SetPixelHeight(uint16_t _ph){ this->_pixelHeight = _ph; }

	element ExGetElement(cell c){ return c.MaterialType;}

	uint32_t FlattenedIndex(uint32_t x, uint32_t y, uint32_t z)
	{
		x = x>w ? w : x; y = y>h ? h : y; z = z>d ? d : z;
		return z * (w * h) + y * w + x; 
	}
	
	
	std::unique_ptr<cell[]> CELL_FRONT_BUFFER; //allowed to use for visual representation, but let's wrap it in a function later

private:///////////////////////////////////////////////////////////////////////////////////////|
	std::unique_ptr<cell[]> CELL_BACK_BUFFER;    ///////////////////////////////////////////// |
	std::unique_ptr<MaterialAttributes[]> matAtt;///////////////////////////////////////////// |
public://///////////////////////////////////////////////////////////////////////////////////// |

	uint32_t w = 0;
	uint32_t h = 0;
	uint32_t d = 0;

	uint16_t _pixelWidth  = 10;
	uint16_t _pixelHeight = 10;

	uint16_t _zLevel = 0;

	MaterialAttributes ReadCellAttributes(cell c)
	{
		if(c.MaterialType >= element::size){ printf("\nWARNING: MaterialType: element::%d is greater than element::size. Defaulting to element::air", static_cast<uint32_t>(c.MaterialType)); }
		return c.MaterialType < element::size ? matAtt[static_cast<uint32_t>(c.MaterialType)] : matAtt[static_cast<uint32_t>(element::air)];
	}
};

namespace WINDOWGraphicsOverlay
{
	COLORREF GetMaterialColor(MATRIX::element e)
	{
		switch(e)
		{
			case MATRIX::element::air:   return RGB(173, 216, 230); break;
			case MATRIX::element::water: return RGB(0, 0, 255);     break;
			case MATRIX::element::wood:  return RGB(139, 69, 19);   break;
			case MATRIX::element::fire:  return RGB(255, 0, 0);     break;
			case MATRIX::element::metal: return RGB(169, 169, 169); break;
			default:                	 return RGB(0, 0, 0); break;
		}
	}

	LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
	{
		if (msg == WM_NCCREATE)
    	{
    	    CREATESTRUCT* pcs = reinterpret_cast<CREATESTRUCT*>(lp);
    	    MATRIX* matrix = static_cast<MATRIX*>(pcs->lpCreateParams);
    	   	SetWindowLongPtr(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(matrix));
			return 1;
    	}

		if(msg == WM_NCDESTROY)
		{
			MATRIX* matrix = reinterpret_cast<MATRIX*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
			delete matrix;
			matrix=nullptr;
			SetWindowLongPtr(hwnd, GWLP_USERDATA, 0);
		}

		switch(msg)
		{
			case WM_MOUSEMOVE:
			{
				MATRIX* matrix = reinterpret_cast<MATRIX*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
				CHECK_MATRIX_POPULATION();
				
				uint32_t x = GET_X_LPARAM(lp);
				uint32_t y = GET_Y_LPARAM(lp);

				uint32_t xCell = x / matrix->_pixelWidth;
				uint32_t yCell = y / matrix->_pixelHeight;
				
				MATRIX::cell readcell = wp & MK_LBUTTON ? matrix->WriteDataTo(xCell, yCell, matrix->_zLevel, MATRIX::cell(MATRIX::element::fire))  : matrix->AccessDataAt(xCell, yCell, matrix->_zLevel);
				readcell              = wp & MK_RBUTTON ? matrix->WriteDataTo(xCell, yCell, matrix->_zLevel, MATRIX::cell(MATRIX::element::water)) : matrix->AccessDataAt(xCell, yCell, matrix->_zLevel);

				printf("cell[%d, %d][SLICE: %d]->element: %s\n", xCell, yCell, matrix->_zLevel, matrix->ReadCellAttributes(readcell).name);
			}
			break;
			case WM_KEYDOWN:
			{
				MATRIX* matrix = reinterpret_cast<MATRIX*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
				CHECK_MATRIX_POPULATION();
				
				matrix->_zLevel += wp == VK_UP   ? 1 : 0;
				matrix->_zLevel -= wp == VK_DOWN ? 1 : 0;

				InvalidateRect(hwnd, nullptr, FALSE);
			}
			break;
			case WM_PAINT:
			{
				MATRIX* matrix = reinterpret_cast<MATRIX*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
				CHECK_MATRIX_POPULATION();

				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hwnd, &ps);

				uint32_t zLevel    = matrix->_zLevel;
				int32_t cellWidth  = matrix->_pixelWidth;
				int32_t cellHeight = matrix->_pixelHeight;

				for(int j=0; j<=matrix->h -1; ++j)
				{
					for(int i=0; i<=matrix->w -1; ++i)
					{
						COLORREF color = WINDOWGraphicsOverlay::GetMaterialColor(matrix->CELL_FRONT_BUFFER[matrix->FlattenedIndex(i, j, zLevel)].MaterialType);

						HBRUSH brush = CreateSolidBrush(color);
						SelectObject(hdc, brush);
						Rectangle(hdc, i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight);
						DeleteObject(brush);
					}
				}

				EndPaint(hwnd, &ps);
			}
			break;
			case WM_DESTROY: PostQuitMessage(0); break;
			default: return DefWindowProc(hwnd, msg, wp, lp); break;
		}

		return 0;
	}

	void ShowErrorMessage(const char* errorText) {
		int len = MultiByteToWideChar(CP_ACP, 0, errorText, -1, NULL, 0);
		wchar_t* wideErrorText = new wchar_t[len];
		MultiByteToWideChar(CP_ACP, 0, errorText, -1, wideErrorText, len);
		MessageBoxW(NULL, wideErrorText, L"Error", MB_ICONERROR | MB_OK);
		delete[] wideErrorText;
	}

	void* CreateWindowOverlay(MATRIX* matrix, uint32_t width, uint32_t height)
	{
		void* _handle = nullptr;

		WNDCLASSEX wc = { };
		wc.cbSize        = sizeof(WNDCLASSEX);
		wc.lpfnWndProc   = WindowProc;
		wc.hInstance     = GetInstance();
		wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
		wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
		wc.lpszClassName = L"3DSimulationOverlay";
		if(!RegisterClassEx(&wc))
		{
			printf("-> Window Class not initialized or registered\n");
		}

		_handle = CreateWindowEx(
			0, wc.lpszClassName, 
			L"REDJADER - SIMULATION", 
			WS_OVERLAPPEDWINDOW, 
			CW_USEDEFAULT, CW_USEDEFAULT, 
			width * matrix->_pixelWidth + width*0.10, 
			height * matrix->_pixelHeight + height*0.40, 
			nullptr, nullptr, GetInstance(), matrix);

		if(_handle==nullptr)
		{
			DWORD errorCode = GetLastError();
    		LPSTR errorText = NULL;
    		FormatMessage(
    		    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
    		    NULL, errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
    		    (LPTSTR)&errorText, 0, NULL);
			
    		printf("Error creating window: %s\n", errorText);
    		LocalFree(errorText);
			return nullptr;
		}
		else
		{
			printf("-> Window Created\n");
		}

		::ShowWindow((HWND)_handle, SW_SHOW);
		::UpdateWindow((HWND)_handle);

		return _handle;
	}
};

INT WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, INT)
{
	MATRIX* matrix = new MATRIX();

	uint32_t width  = 100;
	uint32_t height = 100;
	uint32_t depth  = 100;

	uint32_t SizeOfMatrix = matrix->InitMatrix(width, height, depth);
	HWND _handle = (HWND)WINDOWGraphicsOverlay::CreateWindowOverlay(matrix, width, height);

	MSG msg = {NULL};
	if(_handle)
	{
		while(1)
		{
			matrix->update(_handle);
			while(PeekMessage(&msg, NULL, 0, 0,PM_REMOVE))
			{
				if(msg.message == WM_KEYDOWN)
				{
					if(GetAsyncKeyState(VK_INSERT))
					{
						printf("Goodbye!");
						return msg.wParam;
					}
				}
				::TranslateMessage(&msg);
				::DispatchMessage(&msg);
			}
		}
	}
	else
	{
		MessageBoxW(nullptr, L"WINDOW HANDLE IS EMPTY", L"ERROR", MB_ICONERROR | MB_OK);
		return msg.wParam;
	}

	return EXIT_SUCCESS;
}
