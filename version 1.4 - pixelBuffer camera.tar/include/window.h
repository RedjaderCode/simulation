#ifndef WINDOW_H_
#define WINDOW_H_
#pragma once

#include <windows.h>

#endif
